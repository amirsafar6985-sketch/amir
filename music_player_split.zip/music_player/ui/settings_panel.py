"""
================= SETTINGS PANEL UI =================
ساخت پنل تنظیمات کناری، به شکل مدرن و بخش‌بندی‌شده: زبان، پلی‌لیست، پخش،
پس‌زمینه و اکولایزر ۱۰ باندی. رنگ‌ها با theme.py هماهنگن و متن‌ها با i18n.py.
"""

import customtkinter as ctk

from state import state
from constants import GRADIENT_PRESETS, EQ_PRESETS
from theme import colors
from i18n import t, LANGUAGES, set_language
from background import (
    generate_gradient_image,
    generate_hue_strip,
    hex_for_hue_fraction,
    quick_preview_color,
    set_background_gradient,
    set_background_custom_color,
    pick_background_image,
    clear_background,
)
from playlist_manager import (
    switch_playlist,
    drop_on_playlist,
    create_playlist,
    delete_playlist,
    rename_playlist,
    toggle_delete_buttons,
)
from audio_engine import apply_vlc_equalizer
from settings_manager import save_settings, save_settings_debounced


def toggle_settings():
    if state.settings_open:
        state.settings_panel.grid_remove()
        state.main.grid_columnconfigure(1, weight=0, minsize=0)
        state.settings_open = False
    else:
        state.settings_panel.grid()
        state.main.grid_columnconfigure(1, weight=0, minsize=state.panel_width)
        state.settings_open = True


# ================= کمکی‌های ظاهری =================

def _divider(parent, c):
    ctk.CTkFrame(parent, fg_color=c.get("border", c["hover"]), height=1).pack(
        fill="x", padx=6, pady=(22, 18)
    )


def _register(key, widget):
    """ویجت‌های زبان‌محور رو ذخیره می‌کنه تا با تغییر زبان بشه سریع متنشون رو عوض کرد."""
    state._i18n_widgets[key] = widget
    return widget


def _section_title(parent, key, c):
    row = ctk.CTkFrame(parent, fg_color="transparent")
    row.pack(fill="x", pady=(0, 14))

    label = ctk.CTkLabel(row, text=t(key), font=("Segoe UI", 15, "bold"), text_color=c["accent"])
    label.pack(anchor="w")
    _register(key, label)


def _primary_button(parent, key, command, c):
    btn = ctk.CTkButton(
        parent,
        text=t(key),
        corner_radius=12,
        height=38,
        fg_color=c["accent"],
        hover_color=c["accent_hover"],
        text_color="#ffffff",
        font=("Segoe UI", 13, "bold"),
        command=command,
    )
    return _register(key, btn)


def _ghost_button(parent, key, command, c):
    btn = ctk.CTkButton(
        parent,
        text=t(key),
        corner_radius=12,
        height=36,
        fg_color="transparent",
        border_width=1,
        border_color=c.get("border", c["hover"]),
        hover_color=c["hover"],
        text_color=c["text"],
        font=("Segoe UI", 12),
        command=command,
    )
    return _register(key, btn)


def _danger_button(parent, key, command, c):
    btn = ctk.CTkButton(
        parent,
        text=t(key),
        corner_radius=12,
        height=36,
        fg_color="transparent",
        border_width=1,
        border_color=c.get("danger", "#ff5c7a"),
        hover_color=c.get("danger", "#ff5c7a"),
        text_color=c.get("danger", "#ff5c7a"),
        font=("Segoe UI", 12, "bold"),
        command=command,
    )
    return _register(key, btn)


# ================= ساخت پنل =================

def build_settings_panel():
    c = colors()

    # ================= SETTINGS PANEL FRAME =================
    state.settings_panel = ctk.CTkFrame(
        state.main,
        width=state.panel_width,
        corner_radius=20,
        border_width=1,
        border_color=c.get("border", c["hover"]),
        fg_color=c["glass"],
    )

    state.app.update()

    state.settings_panel.grid(
        row=0,
        column=1,
        rowspan=2,
        sticky="nsew",
        padx=(0, 20),
        pady=20,
    )

    state.settings_panel.grid_propagate(False)
    state.settings_panel.grid_remove()

    # دکمه‌ی شناور تنظیمات - ساده و بدون حاشیه (بدون رینگ سیاه دورش)
    state.settings_btn = ctk.CTkButton(
        state.app,
        text="⚙",
        width=50,
        height=50,
        corner_radius=25,
        fg_color="transparent",
        text_color="#ffffff",
        hover_color=c["accent"],
        border_width=0,
        bg_color="transparent",
        font=("Segoe UI", 18),
        command=toggle_settings,
    )
    state.settings_btn.place(relx=1.0, x=-24, y=24, anchor="ne")
    state.settings_btn._canvas.configure(highlightthickness=0, borderwidth=0)

    state.settings_scroll = ctk.CTkScrollableFrame(
        state.settings_panel,
        fg_color=c["glass"],
    )
    state.settings_scroll.pack(fill="both", expand=True, padx=14, pady=(64, 16))

    header = ctk.CTkFrame(state.settings_scroll, fg_color="transparent")
    header.pack(fill="x", pady=(0, 4))

    title_lbl = ctk.CTkLabel(header, text=t("settings_title"), font=("Segoe UI", 21, "bold"), text_color=c["text"])
    title_lbl.pack(anchor="w")
    _register("settings_title", title_lbl)

    subtitle_lbl = ctk.CTkLabel(
        header, text=t("settings_subtitle"), font=("Segoe UI", 11), text_color=c["subtext"]
    )
    subtitle_lbl.pack(anchor="w", pady=(2, 0))
    _register("settings_subtitle", subtitle_lbl)

    _divider(state.settings_scroll, c)

    _build_language_section(c)
    _divider(state.settings_scroll, c)
    _build_playlist_controls(c)
    _divider(state.settings_scroll, c)
    _build_playback_switches(c)
    _divider(state.settings_scroll, c)
    _build_background_section(c)
    _divider(state.settings_scroll, c)
    _build_equalizer_section(c)


def _build_language_section(c):
    _section_title(state.settings_scroll, "section_language", c)

    initial = LANGUAGES.get(state.language, LANGUAGES["en"])
    code_by_label = {label: code for code, label in LANGUAGES.items()}

    def _on_pick(label):
        set_language(code_by_label.get(label, "en"))

    lang_switch = ctk.CTkOptionMenu(
        state.settings_scroll,
        values=list(LANGUAGES.values()),
        corner_radius=12,
        height=38,
        fg_color=c["card"],
        button_color=c["accent"],
        button_hover_color=c["accent_hover"],
        text_color=c["text"],
        command=_on_pick,
    )
    lang_switch.set(initial)
    lang_switch.pack(fill="x")
    state._i18n_widgets["_lang_switch"] = lang_switch


def _build_playlist_controls(c):
    _section_title(state.settings_scroll, "section_playlist", c)

    state.playlist_selector = ctk.CTkOptionMenu(
        state.settings_scroll,
        values=list(state.playlists.keys()),
        corner_radius=12,
        height=38,
        fg_color=c["card"],
        button_color=c["accent"],
        button_hover_color=c["accent_hover"],
        text_color=c["text"],
        command=lambda choice: switch_playlist(choice),
    )
    state.playlist_selector.bind("<ButtonRelease-3>", drop_on_playlist)
    state.playlist_selector.pack(fill="x", pady=(0, 10))

    row1 = ctk.CTkFrame(state.settings_scroll, fg_color="transparent")
    row1.pack(fill="x", pady=(0, 8))
    row1.grid_columnconfigure((0, 1), weight=1)

    _ghost_button(row1, "new_playlist", create_playlist, c).grid(row=0, column=0, sticky="ew", padx=(0, 6))
    _ghost_button(row1, "rename_playlist", rename_playlist, c).grid(row=0, column=1, sticky="ew", padx=(6, 0))

    row2 = ctk.CTkFrame(state.settings_scroll, fg_color="transparent")
    row2.pack(fill="x", pady=(0, 12))
    row2.grid_columnconfigure((0, 1), weight=1)

    _danger_button(row2, "delete_playlist", delete_playlist, c).grid(row=0, column=0, sticky="ew", padx=(0, 6))
    _danger_button(row2, "clear_songs", _clear_playlist_songs, c).grid(row=0, column=1, sticky="ew", padx=(6, 0))

    _primary_button(state.settings_scroll, "add_song", _load_music, c).pack(fill="x")


def _clear_playlist_songs():
    state.playlists[state.current_playlist].clear()
    for card, _title in state.cards:
        card.destroy()
    state.cards.clear()
    save_settings()


def _load_music():
    from playlist_manager import load_music
    load_music()


def _build_playback_switches(c):
    _section_title(state.settings_scroll, "section_playback", c)

    def _switch(key, on_toggle):
        sw = ctk.CTkSwitch(
            state.settings_scroll,
            text=t(key),
            font=("Segoe UI", 13),
            progress_color=c["accent"],
            button_color="#ffffff",
            button_hover_color=c["accent_hover"],
            fg_color=c["slider_bg"],
            text_color=c["text"],
            command=on_toggle,
        )
        sw.pack(anchor="w", pady=7)
        return _register(key, sw)

    state.auto_resume_switch = _switch(
        "auto_resume",
        lambda: [setattr(state, "auto_resume", state.auto_resume_switch.get()), save_settings()],
    )

    state.shuffle_switch = _switch(
        "shuffle",
        lambda: [setattr(state, "shuffle_mode", state.shuffle_switch.get()), save_settings()],
    )

    state.repeat_switch = _switch(
        "repeat_one",
        lambda: [
            setattr(state, "repeat_mode", "one" if state.repeat_switch.get() else "all"),
            save_settings(),
        ],
    )

    state.delete_switch = _switch(
        "show_delete_buttons",
        lambda: toggle_delete_buttons(state.delete_switch.get()),
    )


def _build_background_section(c):
    _section_title(state.settings_scroll, "section_background", c)

    background_grid = ctk.CTkFrame(state.settings_scroll, fg_color="transparent")
    background_grid.pack(pady=(0, 12))

    state._bg_swatch_buttons = {}

    bg_grid_cols = 3
    for bg_i, (bg_name, bg_stops) in enumerate(GRADIENT_PRESETS.items()):
        thumb_pil = generate_gradient_image((44, 44), bg_stops)
        thumb_img = ctk.CTkImage(light_image=thumb_pil, dark_image=thumb_pil, size=(44, 44))
        state._bg_thumb_refs.append(thumb_img)

        bg_btn = ctk.CTkButton(
            background_grid,
            text="",
            image=thumb_img,
            width=44,
            height=44,
            corner_radius=12,
            fg_color="transparent",
            border_width=0,
            border_color=c["accent"],
            hover_color=c["hover"],
            command=lambda n=bg_name: set_background_gradient(n),
        )
        bg_btn.grid(row=bg_i // bg_grid_cols, column=bg_i % bg_grid_cols, padx=5, pady=5)
        state._bg_swatch_buttons[bg_name] = bg_btn

    _refresh_swatch_selection(c)

    # ---------- انتخاب رنگ دلخواه (نوار عمودی، نه چرخ رنگ) ----------
    color_label = ctk.CTkLabel(
        state.settings_scroll,
        text=t("custom_color"),
        font=("Segoe UI", 12, "bold"),
        text_color=c["subtext"],
    )
    color_label.pack(anchor="w", pady=(4, 6))
    _register("custom_color", color_label)

    strip_w, strip_h = 250, 170
    hue_pil = generate_hue_strip(strip_w, strip_h)
    hue_ctk_img = ctk.CTkImage(light_image=hue_pil, dark_image=hue_pil, size=(strip_w, strip_h))
    state._hue_strip_ref = hue_ctk_img  # جلوگیری از garbage collection

    hue_strip = ctk.CTkLabel(state.settings_scroll, text="", image=hue_ctk_img, corner_radius=12)
    hue_strip.pack(pady=(0, 12))

    def _hue_at(event):
        h = max(hue_strip.winfo_height(), 1)
        y = min(max(event.y, 0), h - 1)
        return hex_for_hue_fraction(y / max(h - 1, 1))

    def _on_drag(event):
        quick_preview_color(_hue_at(event))

    def _on_release(event):
        set_background_custom_color(_hue_at(event))

    hue_strip.bind("<Button-1>", _on_drag)
    hue_strip.bind("<B1-Motion>", _on_drag)
    hue_strip.bind("<ButtonRelease-1>", _on_release)

    _ghost_button(state.settings_scroll, "choose_image", pick_background_image, c).pack(fill="x", pady=(0, 8))
    _danger_button(state.settings_scroll, "remove_background", clear_background, c).pack(fill="x")


def _refresh_swatch_selection(c=None):
    """
    فقط حاشیه‌ی نشانگر انتخاب رو روی سواچ‌های پس‌زمینه به‌روز می‌کنه، بدون
    این‌که چیزی ساخته یا نابود بشه - تا نه اسکرول پنل تنظیمات ریست بشه و نه
    وضعیت سوییچ‌ها/پلی‌لیست از دست بره.
    """
    c = c or colors()
    for name, btn in getattr(state, "_bg_swatch_buttons", {}).items():
        is_selected = state.background_mode == "gradient" and state.background_value == name
        try:
            btn.configure(
                border_width=2 if is_selected else 0,
                border_color=c["accent"],
            )
        except Exception:
            pass


def _build_equalizer_section(c):
    _section_title(state.settings_scroll, "section_equalizer", c)

    state.equalizer_menu = ctk.CTkOptionMenu(
        state.settings_scroll,
        values=list(EQ_PRESETS.keys()),
        corner_radius=12,
        height=38,
        fg_color=c["card"],
        button_color=c["accent"],
        button_hover_color=c["accent_hover"],
        text_color=c["text"],
        command=change_eq,
    )
    state.equalizer_menu.pack(fill="x", pady=(0, 14))
    state.equalizer_menu.set(state.equalizer_mode)

    # -------- MANUAL SLIDERS (۱۰ باند) --------
    manual_frame = ctk.CTkFrame(state.settings_scroll, fg_color="transparent")
    manual_frame.pack(fill="x")

    state.manual_sliders = []

    for band_index in range(state.EQ_BAND_COUNT):
        freq_label = (
            format_freq_label(state.EQ_BAND_FREQS[band_index])
            if band_index < len(state.EQ_BAND_FREQS)
            else f"Band {band_index + 1}"
        )

        ctk.CTkLabel(
            manual_frame, text=freq_label, font=("Segoe UI", 11), text_color=c["subtext"]
        ).pack()

        slider = ctk.CTkSlider(
            manual_frame,
            from_=-20,
            to=20,
            width=230,
            height=6,
            corner_radius=999,
            progress_color=c["accent"],
            button_color=c["accent"],
            button_hover_color=c["accent_hover"],
            fg_color=c["slider_bg"],
            command=make_manual_band_handler(band_index),
        )
        slider.set(state.manual_eq[band_index] if band_index < len(state.manual_eq) else 0)
        slider.pack(pady=(2, 12))

        state.manual_sliders.append(slider)


def change_eq(choice):
    state.equalizer_mode = choice
    apply_vlc_equalizer()
    save_settings()


def format_freq_label(freq):
    freq = float(freq)
    if freq >= 1000:
        val = freq / 1000
        if val == int(val):
            return f"{int(val)}kHz"
        return f"{val:g}kHz"
    return f"{int(freq)}Hz"


def make_manual_band_handler(index):
    def handler(value):
        state.manual_eq[index] = float(value)
        if state.equalizer_mode == "Manual":
            apply_vlc_equalizer()
        save_settings_debounced()
    return handler


# ================= رفرش زبان/پس‌زمینه بدون بازسازی کامل =================

def refresh_settings_texts():
    """
    بعد از تغییر زبان صدا زده میشه: فقط متن ویجت‌های ثبت‌شده رو عوض می‌کنه،
    بدون این‌که چیزی نابود/بازسازی بشه (پس اسکرول و انتخاب‌های فعلی حفظ میشن).
    """
    for key, widget in list(state._i18n_widgets.items()):
        if key == "_lang_switch":
            try:
                widget.configure(values=list(LANGUAGES.values()))
                widget.set(LANGUAGES.get(state.language, LANGUAGES["en"]))
            except Exception:
                pass
            continue
        try:
            widget.configure(text=t(key))
        except Exception:
            pass


def refresh_background_selection():
    """از background.py بعد از انتخاب/حذف پس‌زمینه صدا زده میشه."""
    _refresh_swatch_selection()
