"""
================= PLAYER BAR UI =================
ساخت نوار پخش پایین صفحه: آیکن آهنگ جاری، نام + وضعیت پخش، اسلایدر پیشرفت،
دکمه‌های کنترل (به شکل مدرن با رنگ accent) و کنترل صدا.
"""

import customtkinter as ctk

from state import state
from theme import colors
from constants import RADIUS_PILL
from i18n import t
from audio_engine import (
    preview_seek,
    start_drag,
    stop_drag,
    prev_song,
    next_song,
    toggle_play_pause,
)
from settings_manager import save_settings_debounced, save_settings


def build_player_bar():
    c = colors()

    state.player_bar = ctk.CTkFrame(state.main, height=110, corner_radius=0)
    state.player_bar.grid(row=1, column=0, sticky="ew")
    state.player_bar.grid_propagate(False)

    # ---------- LEFT : ICON + SONG NAME ----------
    info_frame = ctk.CTkFrame(state.player_bar, fg_color="transparent")
    info_frame.pack(side="left", padx=(28, 10))

    song_icon = ctk.CTkLabel(
        info_frame,
        text="🎵",
        font=("Segoe UI", 20),
        width=46,
        height=46,
        corner_radius=14,
        fg_color=c["accent"],
        text_color="#ffffff",
    )
    song_icon.pack(side="left", padx=(0, 14))
    state.song_icon = song_icon

    text_col = ctk.CTkFrame(info_frame, fg_color="transparent")
    text_col.pack(side="left")

    state.now_playing_label = ctk.CTkLabel(
        text_col,
        text=t("nothing_playing"),
        font=("Segoe UI", 14, "bold"),
        anchor="w",
    )
    state.now_playing_label.pack(anchor="w")

    state.status_label = ctk.CTkLabel(
        text_col,
        text=t("status_ready"),
        font=("Segoe UI", 11),
        text_color=c["subtext"],
        anchor="w",
    )
    state.status_label.pack(anchor="w")

    # ---------- CENTER (SLIDER + CONTROLS) ----------
    center_frame = ctk.CTkFrame(state.player_bar, fg_color="transparent")
    center_frame.pack(expand=True)

    # --- CONTROLS ROW ---
    controls = ctk.CTkFrame(center_frame, fg_color="transparent")
    controls.pack(pady=(14, 6))

    state.prev_btn = ctk.CTkButton(
        controls,
        text="⏮",
        width=42,
        height=42,
        corner_radius=21,
        fg_color="transparent",
        text_color=c["text"],
        hover_color=c["hover"],
        font=("Segoe UI", 15),
        command=prev_song,
    )
    state.prev_btn.pack(side="left", padx=12)

    state.play_btn = ctk.CTkButton(
        controls,
        text="▶",
        width=58,
        height=58,
        corner_radius=29,
        fg_color=c["accent"],
        text_color="#ffffff",
        hover_color=c["accent_hover"],
        font=("Segoe UI", 18),
        command=toggle_play_pause,
    )
    state.play_btn.pack(side="left", padx=18)

    state.next_btn = ctk.CTkButton(
        controls,
        text="⏭",
        width=42,
        height=42,
        corner_radius=21,
        fg_color="transparent",
        text_color=c["text"],
        hover_color=c["hover"],
        font=("Segoe UI", 15),
        command=next_song,
    )
    state.next_btn.pack(side="left", padx=12)

    # --- SLIDER ROW ---
    progress_frame = ctk.CTkFrame(center_frame, fg_color="transparent")
    progress_frame.pack()

    state.current_time_label = ctk.CTkLabel(
        progress_frame, text="00:00", font=("Segoe UI", 11), text_color=c["subtext"], width=40
    )
    state.current_time_label.pack(side="left", padx=5)

    state.progress = ctk.CTkSlider(
        progress_frame,
        from_=0,
        to=100,
        width=460,
        height=6,
        corner_radius=RADIUS_PILL,
        button_length=14,
        progress_color=c["accent"],
        fg_color=c["slider_bg"],
        button_color=c["accent"],
        button_hover_color=c["accent_hover"],
        command=preview_seek,
    )
    state.progress.pack(side="left", padx=10)

    state.total_time_label = ctk.CTkLabel(
        progress_frame, text="00:00", font=("Segoe UI", 11), text_color=c["subtext"], width=40
    )
    state.total_time_label.pack(side="left", padx=5)

    state.progress.bind("<ButtonPress-1>", lambda e: start_drag())
    state.progress.bind("<ButtonRelease-1>", lambda e: stop_drag())

    # ---------- RIGHT : VOLUME ----------
    volume_frame = ctk.CTkFrame(state.player_bar, fg_color="transparent")
    volume_frame.pack(side="right", padx=28)

    state.volume_value = ctk.DoubleVar(value=70)

    state.volume_icon = ctk.CTkButton(
        volume_frame,
        text="🔊",
        width=42,
        height=42,
        corner_radius=21,
        fg_color="transparent",
        hover_color=c["hover"],
        text_color=c["text"],
        font=("Segoe UI", 16),
        command=toggle_mute,
    )
    state.volume_icon.pack(side="left", padx=(0, 10))

    state.volume_label = ctk.CTkLabel(
        volume_frame,
        text="70%",
        font=("Segoe UI", 12, "bold"),
        text_color=c["subtext"],
        width=38,
    )
    state.volume_label.pack(side="left", padx=(0, 10))

    state.volume = ctk.CTkSlider(
        volume_frame,
        from_=0,
        to=100,
        width=140,
        height=6,
        corner_radius=RADIUS_PILL,
        variable=state.volume_value,
        command=change_volume,
        progress_color=c["accent"],
        fg_color=c["slider_bg"],
        button_color=c["accent"],
        button_hover_color=c["accent_hover"],
        button_length=1,
    )
    state.volume.pack(side="left")

    state.volume.set(70)
    update_volume_icon(70)


def update_volume_icon(v):
    if v == 0:
        state.volume_icon.configure(text="🔇")
    elif v <= 30:
        state.volume_icon.configure(text="🔈")
    elif v <= 70:
        state.volume_icon.configure(text="🔉")
    else:
        state.volume_icon.configure(text="🔊")


def change_volume(value):
    v = int(float(value))

    state.volume_label.configure(text=f"{v}%")
    update_volume_icon(v)

    if v == 0:
        state.is_muted = True
    else:
        state.is_muted = False
        state.last_volume_before_mute = v

    state.player.audio_set_volume(v)
    save_settings_debounced()


def toggle_mute():
    if not state.is_muted:
        # ذخیره آخرین صدا
        state.last_volume_before_mute = int(state.volume_value.get())

        # صفر کردن کامل
        state.volume_value.set(0)
        state.volume_label.configure(text="0%")
        update_volume_icon(0)
        state.player.audio_set_volume(0)

        state.is_muted = True
    else:
        # بازگردانی به آخرین مقدار
        restore_volume = state.last_volume_before_mute if state.last_volume_before_mute > 0 else 70

        state.volume_value.set(restore_volume)
        state.volume_label.configure(text=f"{restore_volume}%")
        update_volume_icon(restore_volume)
        state.player.audio_set_volume(restore_volume)

        state.is_muted = False

    save_settings()


def refresh_player_bar_texts():
    """بعد از تغییر زبان، متن‌های ثابتِ نوار پخش (وقتی آهنگی در حال پخش نیست) رو به‌روز می‌کنه."""
    if state.current_index is None and state.now_playing_label:
        state.now_playing_label.configure(text=t("nothing_playing"))

    if state.status_label:
        if state.is_playing:
            state.status_label.configure(text=t("status_playing"))
        elif state.current_index is not None:
            state.status_label.configure(text=t("status_paused"))
        else:
            state.status_label.configure(text=t("status_ready"))
